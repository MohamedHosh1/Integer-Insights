import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * Controller class.
 *
 * @author Mohamed Hosh
 */
public final class NNCalcController1 implements NNCalcController {

    /**
     * Model object.
     */
    private final NNCalcModel model;

    /**
     * View object.
     */
    private final NNCalcView view;

    /**
     * Useful constants.
     */
    private static final NaturalNumber TWO = new NaturalNumber2(2),
            INT_LIMIT = new NaturalNumber2(Integer.MAX_VALUE);

    /**
     * Updates this.view to display this.model, and to allow only operations
     * that are legal given this.model.
     *
     * @param model
     *            the model
     * @param view
     *            the view
     * @ensures [view has been updated to be consistent with model]
     */
    private static void updateViewToMatchModel(NNCalcModel model,
            NNCalcView view) {
        // Get the original and new values from the model
        NaturalNumber theBottom = model.bottom();
        NaturalNumber theTop = model.top();

        // Check if power operation is allowed based on the value of the original number
        if (theBottom.compareTo(INT_LIMIT) <= 0) {
            view.updatePowerAllowed(true);
        } else {
            view.updatePowerAllowed(false);
        }

        // Check if root operation is allowed based on the value of the original number
        if (theBottom.compareTo(TWO) >= 0
                && theBottom.compareTo(INT_LIMIT) <= 0) {
            view.updateRootAllowed(true);
        } else {
            view.updateRootAllowed(false);
        }

        //Check if subtract operation is allowed based on the values of the
        //original and new numbers

        if (theBottom.compareTo(theTop) < 0) {
            view.updateSubtractAllowed(true);
        } else {
            view.updateSubtractAllowed(false);
        }

        // Check if divide operation is allowed based on the value of the original number
        if (theBottom.compareTo(new NaturalNumber2()) > 0) {
            view.updateDivideAllowed(true);
        } else {
            view.updateDivideAllowed(false);
        }

        //Update the display of the original and new values in the view
        view.updateBottomDisplay(theBottom);
        view.updateTopDisplay(theTop);
    }

    /**
     * Constructor.
     *
     * @param model
     *            model to connect to
     * @param view
     *            view to connect to
     */
    public NNCalcController1(NNCalcModel model, NNCalcView view) {
        this.model = model;
        this.view = view;
        updateViewToMatchModel(model, view);
    }

    @Override
    public void processClearEvent() {
        /*
         * Get alias to bottom from model
         */
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        bottom.clear();
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSwapEvent() {
        /*
         * Get aliases to top and bottom from model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        NaturalNumber temp = top.newInstance();
        temp.transferFrom(top);
        top.transferFrom(bottom);
        bottom.transferFrom(temp);
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processEnterEvent() {
        // Get the top and bottom numbers from the model
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Copy the top to the bottom
        bottom.copyFrom(top);

        // Update the view to match the model
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddEvent() {
        // Get the top and bottom numbers from the model
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Add the top to the bottom and clear the top
        bottom.add(top);
        top.clear();

        // Update the view to match the model
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSubtractEvent() {
        // Get the top and bottom numbers from the model
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Subtract the top from the bottom and transfer the result to the top
        bottom.subtract(top);
        top.transferFrom(bottom);

        // Update the view to match the model
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processMultiplyEvent() {
        // Get the top and bottom numbers from the model
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Multiply the top with the bottom and clear the top
        bottom.multiply(top);
        top.clear();

        // Update the view to match the model
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processDivideEvent() {
        // Get the top and bottom numbers from the model
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //Divide the bottom by the top, transfer the top to the bottom and t he
        // remainder to the top

        NaturalNumber remainder = bottom.divide(top);
        top.transferFrom(bottom);
        bottom.transferFrom(remainder);

        // Update the view to match the model
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processPowerEvent() {
        // Get the top and bottom numbers from the model
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Raise the bottom to the power of the top and transfer the result to the top
        bottom.power(top.toInt());
        top.transferFrom(bottom);

        // Update the view to match the model
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processRootEvent() {
        // Get the top and bottom numbers from the model
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //Calculate the root of the bottom with the top as the root and
        //transfer the result to the top

        bottom.root(top.toInt());
        top.transferFrom(bottom);

        // Update the view to match the model
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddNewDigitEvent(int digit) {
        // Get the bottom number from the model
        NaturalNumber bottom = this.model.bottom();

        // Multiply the bottom number by 10 and add the digit
        bottom.multiplyBy10(digit);

        // Update the view to match the model
        updateViewToMatchModel(this.model, this.view);
    }
}
